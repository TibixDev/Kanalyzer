<template>
    <div class="container text-lg mt-5 mx-auto px-4">
        <h1 class="text-7xl text-center mb-12">Kanalyzer</h1>
        <p><strong>KanaLyzer</strong> is a free and open source webapp which helps you learn Hiragana and Katakana.</p>
        <p>Repository: <a href="#" class="text-purple-400">GitHub</a></p>
        <p>Copyright (c) 2021 TibixDev</p>
    </div>
</template>

<script>
export default {
    name: "About"
}
</script>

<style scoped>

</style>