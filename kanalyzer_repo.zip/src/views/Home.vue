<template>
    <div class="container text-xl mt-5 text-center mx-auto px-4">
        <h1 class="text-7xl mb-12">Kanalyzer</h1>
        <p>Do you want to learn / practice Hiragana and Katakana?</p>
        <p>We have the perfect tool for you.</p>
        <button @click="$router.push('Practice')" class="bg-indigo-500 mt-5 px-6 py-4 rounded-lg hover:bg-indigo-600 transition duration-300">Get Started</button>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>